import React from 'react'
import LogoAnim from '../Components/logoAnim'

const launch = () => {
  return (
    <div>
        <LogoAnim />
      
    </div>
  )
}
//changeee
//khureufrwfhl
export default launch
